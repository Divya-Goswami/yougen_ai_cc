"""
Models Package

Contains data models and database schemas.
""" 