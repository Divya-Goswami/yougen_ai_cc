"""
Views Package

Contains HTML templates and view logic.
""" 