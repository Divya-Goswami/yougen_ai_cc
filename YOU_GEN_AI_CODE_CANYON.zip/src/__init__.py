"""
YouGen AI - YouTube Content Generator
Source Package

This package contains the main application source code.
"""

__version__ = "1.0.0"
__author__ = "YouGen AI Team"
__email__ = "support@yougenai.com" 