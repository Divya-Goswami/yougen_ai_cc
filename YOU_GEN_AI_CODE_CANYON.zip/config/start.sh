#!/bin/bash
echo "🎬 Starting YouGen AI YouTube Content Generator..."
echo ""

# Activate virtual environment
source venv/bin/activate

# Start the application
python app.py
